# HTML basics

## Objective
- Following recent cryptocurrency trends, you have been put in charge of your company wide email promoting  information for the top 10 coins. Information should include the coins name, rank and current information for the following: market cap, price, 24 hour volume, circulating supply and 24 hour change. The coin rank is determined by market cap. You have been provided a wire frame for reference.

## Instructions
- Create a website for current cryptocurrency trends using tables and html attributes
- Your code will be used in an email so it cannot include any css !
- Use the provided wire frame for the page's layout
